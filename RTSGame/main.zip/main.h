#pragma once
#include <iostream>
#include <SDL.h>
#include <vector>
const int tilesize = 25;